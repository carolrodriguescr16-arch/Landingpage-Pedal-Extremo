import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'

import { 
  Phone, 
  MapPin, 
  Instagram, 
  Truck, 
  Wrench, 
  ShieldCheck, 
  Battery, 
  Settings, 
  Droplets, 
  Home as HomeIcon,
  ChevronDown,
  MessageCircle,
  Star,
  X,
  ZoomIn,
  ZoomOut
} from 'lucide-react'
import '../App.css'
import heroImage from '../assets/novos/scooter-maxus.jpg'
import storeImage1 from '../assets/WhatsAppImage2025-10-11at12.15.36(1).jpeg'
import storeImage2 from '../assets/WhatsAppImage2025-10-11at12.15.36(2).jpeg'
import storeImage3 from '../assets/WhatsAppImage2025-10-11at12.15.36(3).jpeg'
import storeImage4 from '../assets/WhatsAppImage2025-10-11at12.15.36(4).jpeg'
import storeImage5 from '../assets/WhatsAppImage2025-10-11at12.15.36(5).jpeg'
import storeImage6 from '../assets/WhatsAppImage2025-10-11at12.15.36(6).jpeg'
import productS2 from '../assets/scooter-s2.jpeg'
import productJ10 from '../assets/scooter-j10.jpeg'
import productJet from '../assets/scooter-jet.jpeg'
import productWSD2 from '../assets/novos/triciclo-wsd2.jpeg'
import productH9 from '../assets/bike-h9.jpeg'
import productDot from '../assets/novos/scooter-dot.jpeg'
import productWD5 from '../assets/novos/scooter-wd5.jpg'
import productMaxus from '../assets/novos/scooter-maxus.jpg'
import productAlfa from '../assets/triciclo-alfa.jpg'
import productGT2000 from '../assets/bike-gt2000.jpg'
import productLoop from '../assets/triciclo-loop.jpg'

export default function Home() {
  const [openFaq, setOpenFaq] = useState<number | null>(null)
  const [selectedImage, setSelectedImage] = useState<string | null>(null)
  const [imageZoom, setImageZoom] = useState(1)

  const whatsappNumber = "5537998050088"
  const whatsappLink = `https://wa.me/${whatsappNumber}`
  const instagramLink = "https://www.instagram.com/pedalextremo.mobilidade"

  const handleWhatsAppClick = (productName = '') => {
    const message = productName 
      ? `Olá! Tenho interesse no ${productName}. Gostaria de mais informações!`
      : `Olá! Gostaria de saber mais sobre os veículos elétricos da Pedal Extremo!`
    window.open(`${whatsappLink}?text=${encodeURIComponent(message)}`, '_blank')
  }

  const handleInstagramClick = () => {
    const username = 'pedalextremo.mobilidade'
    const instagramAppLink = `instagram://user?username=${username}`
    const instagramWebLink = `https://www.instagram.com/${username}`
    
    window.location.href = instagramAppLink
    
    setTimeout(() => {
      window.open(instagramWebLink, '_blank')
    }, 1500)
  }

  const handleImageClick = (image: string) => {
    setSelectedImage(image)
    setImageZoom(1)
  }

  const handleCloseImage = () => {
    setSelectedImage(null)
    setImageZoom(1)
  }

  const handleZoomIn = () => {
    setImageZoom(prev => Math.min(prev + 0.5, 3))
  }

  const handleZoomOut = () => {
    setImageZoom(prev => Math.max(prev - 0.5, 1))
  }

  const products = [
    {
      name: "Scooter S2 1000W",
      category: "scooter",
      image: productS2,
      features: [
        "1000W de potência",
        "Bateria de lítio 60v 30ah",
        "Autonomia de 45 a 60km",
        "Velocidade máx. 32km/h",
        "Carga máxima 200kg",
        "Alarme antifurto"
      ],
      prices: {
        normal: "R$ 14.165,00",
        installment: "18x de R$ 787,00",
        cash: "R$ 12.000,00"
      }
    },
    {
      name: "Scooter J-10 800W",
      category: "scooter",
      image: productJ10,
      features: [
        "800W de potência",
        "Bateria de lítio 20ah removível",
        "Autonomia de até 55km",
        "Velocidade máx. 32km/h",
        "CX som com suporte p/ celular",
        "Alarme antifurto e cartão NFC"
      ],
      prices: {
        normal: "R$ 7.002,00",
        installment: "18x de R$ 389,00",
        cash: "R$ 5.990,00"
      }
    },
    {
      name: "Scooter Jet 1000W",
      category: "scooter",
      image: productJet,
      features: [
        "1000W de potência",
        "Bateria de lítio 60v 20ah",
        "Autonomia de até 50km",
        "Velocidade máxima 32km/h",
        "Carga máxima 150kg",
        "Alarme antifurto"
      ],
      prices: {
        normal: "R$ 12.996,00",
        installment: "18x de R$ 722,00",
        cash: "R$ 10.990,00"
      }
    },
    {
      name: "Scooter Dot 1000W",
      category: "scooter",
      image: productDot,
      features: [
        "Autopropelido 1000W",
        "Bateria de lítio 60v 20ah",
        "Autonomia de 30 a 50km",
        "Velocidade máx. 32km/h",
        "Recarga em 6 a 8 horas",
        "3 níveis de velocidade",
        "Carga máxima 150kg",
        "Alarme antifurto",
        "6 meses garantia motor/bateria"
      ],
      prices: {
        normal: "R$ 12.045,00",
        installment: "18x de R$ 669,17",
        cash: "R$ 10.200,00"
      }
    },
    {
      name: "Scooter WD-5 1000W",
      category: "scooter",
      image: productWD5,
      features: [
        "Autopropelido 1000W",
        "Bateria de lítio 60v 25ah",
        "Autonomia de até 60km",
        "Velocidade máx. 32km/h",
        "Recarga em 6 a 8 horas",
        "3 níveis de velocidade",
        "Carga máxima 150kg",
        "Alarme antifurto"
      ],
      prices: {
        normal: "R$ 13.590,00",
        installment: "18x de R$ 755,00",
        cash: "R$ 11.490,00"
      }
    },
    {
      name: "Scooter Maxus 1000W",
      category: "scooter",
      image: productMaxus,
      features: [
        "Autopropelido 1000W",
        "Bateria de lítio 60v 20.8ah",
        "Autonomia de até 50km",
        "Velocidade máx. 32km/h",
        "Recarga em 6 a 8 horas",
        "3 níveis de velocidade",
        "Carga máxima 150kg",
        "Alarme antifurto"
      ],
      prices: {
        normal: "R$ 11.000,00",
        installment: "18x de R$ 611,11",
        cash: "R$ 9.990,00"
      }
    },
    {
      name: "Triciclo WSD 1000W - 2 Lugares",
      category: "triciclo",
      image: productWSD2,
      features: [
        "1000W de potência",
        "Bateria de lítio 60v 35ah",
        "Autonomia de até 60km",
        "Velocidade máx. 32km/h",
        "Carga máxima 200kg",
        "Alarme antifurto"
      ],
      prices: {
        normal: "R$ 14.034,00",
        installment: "18x de R$ 779,67",
        cash: "R$ 11.890,00"
      }
    },
    {
      name: "Triciclo Alfa 1000W",
      category: "triciclo",
      image: "/triciclo-alfa.jpg",
      features: [
        "Autopropelido 1000W",
        "Bateria de chumbo 60v",
        "Autonomia de até 40km",
        "Velocidade máx. 32km/h",
        "Recarga em 6 a 8 horas",
        "3 níveis de velocidade",
        "Carga máxima 150kg",
        "Alarme antifurto"
      ],
      prices: {
        normal: "R$ 15.390,00",
        installment: "18x de R$ 855,00",
        cash: "R$ 12.990,00"
      }
    },
    {
      name: "Triciclo Elétrico Loop 1000W",
      category: "triciclo",
      image: "/triciclo-loop.jpg",
      features: [
        "Autopropelido 1000W",
        "Bateria de chumbo 60v",
        "Autonomia de até 40km",
        "Velocidade máx. 32km/h",
        "Recarga em 6 a 8 horas",
        "3 níveis de velocidade",
        "Carga máxima 150kg",
        "Alarme antifurto"
      ],
      prices: {
        normal: "R$ 12.399,00",
        installment: "18x de R$ 688,83",
        cash: "R$ 10.700,00"
      }
    },
    {
      name: "Bike Elétrica GT2000 1000W",
      category: "bike",
      image: "/bike-gt2000.jpg",
      features: [
        "Autopropelido 1000W",
        "Bateria de lítio 48v 30ah",
        "Autonomia de até 60km",
        "Velocidade máx. 32km/h",
        "Recarga em 6 a 8 horas",
        "5 níveis de velocidade",
        "Carga máxima 150kg"
      ],
      prices: {
        normal: "R$ 14.750,00",
        installment: "18x de R$ 819,44",
        cash: "R$ 12.490,00"
      }
    },
    {
      name: "Bike Elétrica H9 1000W",
      category: "bike",
      image: productH9,
      features: [
        "1000W de potência",
        "Bateria de lítio 48v 15ah",
        "Autonomia media 50km",
        "Velocidade máx. 32km/h",
        "5 níveis de velocidade",
        "Alarme antifurto + Cartão NFC"
      ],
      prices: {
        normal: "R$ 10.710,00",
        installment: "18x de R$ 595,00",
        cash: "R$ 8.990,00"
      }
    }
  ]

  const testimonials = [
    {
      name: "José Carlos, 68 anos",
      role: "Aposentado",
      text: "O triciclo mudou minha vida. Voltei a ter independência para ir ao mercado, passear na praça... A equipe da Pedal Extremo foi super atenciosa, me entregaram em casa e explicaram tudo direitinho. O pagamento na entrega me deu muita segurança.",
      rating: 5
    },
    {
      name: "Mariana Lima, 25 anos",
      role: "Estudante",
      text: "Minha scooter é tudo! Economizo muito com transporte e ainda chego rápido na faculdade, sem me preocupar com estacionamento. O atendimento pelo WhatsApp foi ótimo, tiraram todas as minhas dúvidas antes da compra.",
      rating: 5
    },
    {
      name: "Ricardo F., 42 anos",
      role: "Entregador",
      text: "Comprei a bike elétrica para trabalhar e foi o melhor investimento. A autonomia é excelente, aguento o dia todo. A oficina deles também é um diferencial, sei que tenho suporte se precisar. Recomendo demais!",
      rating: 5
    }
  ]

  const faqs = [
    {
      question: "Quais são as formas de pagamento?",
      answer: "Aceitamos Pix, dinheiro (com desconto especial à vista) e parcelamos em até 18x no cartão de crédito. E o melhor: você só paga na entrega!"
    },
    {
      question: "Preciso de CNH para pilotar?",
      answer: "A legislação varia. Nossos veículos se enquadram em diferentes categorias. Entre em contato e nossa equipe irá te orientar sobre o modelo ideal para você, explicando toda a documentação necessária para sua cidade."
    },
    {
      question: "Como funciona a garantia?",
      answer: "A garantia varia de acordo com cada produto e é coberta diretamente pela nossa loja. Entre em contato pelo WhatsApp para consultar as condições específicas do modelo que você deseja."
    },
    {
      question: "Vocês entregam na minha cidade?",
      answer: "Atendemos todo o estado de Minas Gerais com entrega e pagamento no ato. Também enviamos para diversas outras regiões do Brasil via transportadora. Consulte as condições para sua localidade!"
    }
  ]

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section - Otimizado para Mobile */}
      <section 
        className="relative min-h-screen flex items-center justify-center text-white px-4 py-20"
        style={{
          backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url(${heroImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="container mx-auto text-center z-10">
          <h1 className="text-3xl sm:text-4xl md:text-6xl lg:text-7xl font-bold mb-4 sm:mb-6 animate-fade-in-up leading-tight">
            Sua Liberdade Elétrica Começa Agora.<br />
            <span className="text-yellow-400">Pague Só na Entrega!</span>
          </h1>
          <p className="text-base sm:text-lg md:text-xl lg:text-2xl mb-6 sm:mb-8 max-w-3xl mx-auto px-4">
            Scooters, Triciclos e Bikes Elétricas com Garantia Real, Oficina Própria e Entregamos em Grande Parte de MG
          </p>
          <Button 
            size="lg" 
            className="bg-green-500 hover:bg-green-600 text-white font-bold py-5 sm:py-6 px-6 sm:px-8 text-base sm:text-lg w-full sm:w-auto"
            onClick={() => handleWhatsAppClick()}
          >
            <MessageCircle className="mr-2 h-5 w-5 sm:h-6 sm:w-6" />
            Quero Meu Veículo Elétrico
          </Button>
          
          {/* Seta animada indicando scroll */}
          <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
            <svg 
              className="w-8 h-8 text-white opacity-75" 
              fill="none" 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              strokeWidth="2" 
              viewBox="0 0 24 24" 
              stroke="currentColor"
            >
              <path d="M19 14l-7 7m0 0l-7-7m7 7V3"></path>
            </svg>
          </div>
        </div>
      </section>

      {/* Diferenciais - Otimizado para Mobile */}
      <section className="py-12 sm:py-16 md:py-20 bg-gray-50 px-4">
        <div className="container mx-auto">
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-center mb-8 sm:mb-12">
            Por Que Escolher a <span className="text-red-600">Pedal Extremo</span>?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <Truck className="w-12 h-12 sm:w-16 sm:h-16 mx-auto text-green-500 mb-4" />
                <CardTitle className="text-lg sm:text-xl md:text-2xl">Pagamento na Entrega</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm sm:text-base text-gray-600">
                  Você só paga quando receber seu veículo. Segurança e confiança para você!
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <Wrench className="w-12 h-12 sm:w-16 sm:h-16 mx-auto text-blue-500 mb-4" />
                <CardTitle className="text-lg sm:text-xl md:text-2xl">Oficina Própria</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm sm:text-base text-gray-600">
                  Manutenção e suporte técnico especializado em Formiga-MG. Estamos aqui para você!
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <ShieldCheck className="w-12 h-12 sm:w-16 sm:h-16 mx-auto text-red-600 mb-4" />
                <CardTitle className="text-lg sm:text-xl md:text-2xl">Garantia Real</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm sm:text-base text-gray-600">
                  Garantia coberta pela nossa loja. Se tiver problema, resolvemos!
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Depoimentos - Otimizado para Mobile */}
      <section className="py-12 sm:py-16 md:py-20 bg-white px-4">
        <div className="container mx-auto">
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-center mb-8 sm:mb-12">
            O Que Nossos <span className="text-red-600">Clientes Dizem</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center gap-1 mb-2">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 sm:w-5 sm:h-5 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <CardTitle className="text-base sm:text-lg">{testimonial.name}</CardTitle>
                  <CardDescription className="text-sm">{testimonial.role}</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm sm:text-base text-gray-600 italic">"{testimonial.text}"</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Galeria da Loja - Otimizado para Mobile */}
      <section className="py-12 sm:py-16 md:py-20 bg-gray-50 px-4">
        <div className="container mx-auto">
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-center mb-8 sm:mb-12">
            Conheça Nossa <span className="text-red-600">Loja</span>
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6">
            {[storeImage1, storeImage2, storeImage3, storeImage4, storeImage5, storeImage6].map((image, index) => (
              <div key={index} className="overflow-hidden rounded-lg shadow-md hover:shadow-xl transition-shadow">
                <img 
                  src={image} 
                  alt={`Loja Pedal Extremo ${index + 1}`} 
                  className="w-full h-40 sm:h-48 md:h-64 object-cover hover:scale-110 transition-transform duration-300"
                />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Produtos - Otimizado para Mobile */}
      <section className="py-12 sm:py-16 md:py-20 bg-white px-4">
        <div className="container mx-auto">
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-center mb-4 sm:mb-6">
            Nossos <span className="text-red-600">Produtos</span>
          </h2>
          
          {/* Aviso de mais modelos */}
          <div className="bg-yellow-50 border-2 border-yellow-400 rounded-lg p-4 mb-8 sm:mb-12 text-center">
            <p className="text-sm sm:text-base md:text-lg font-semibold text-gray-800">
              ⚡ Estes são apenas alguns dos nossos modelos! Temos muito mais opções disponíveis.
            </p>
            <p className="text-xs sm:text-sm text-gray-600 mt-2">
              Chame no WhatsApp para conhecer toda nossa linha!
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {products.map((product, index) => (
              <Card key={index} className="hover:shadow-xl transition-shadow">
                <CardHeader className="p-4 sm:p-6">
                  <div className="relative h-56 sm:h-64 mb-4 overflow-hidden rounded-lg bg-gray-100 cursor-pointer group"
                       onClick={() => handleImageClick(product.image)}>
                    <img 
                      src={product.image} 
                      alt={product.name}
                      className="w-full h-full object-cover transition-transform duration-300"
                    />

                  </div>
                  <CardTitle className="text-lg sm:text-xl md:text-2xl mb-2">{product.name}</CardTitle>
                  <div className="flex flex-col gap-2 mb-4">
                    {product.features.map((feature, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-xs sm:text-sm text-gray-700">
                        <span className="text-green-600 font-bold flex-shrink-0">✓</span>
                        <span>{feature}</span>
                      </div>
                    ))}
                  </div>
                </CardHeader>
                <CardContent className="p-4 sm:p-6 pt-0">
                  <div className="mb-4">
                    <p className="text-xs sm:text-sm text-gray-500 line-through">{product.prices.normal}</p>
                    <p className="text-base sm:text-lg md:text-xl font-bold text-green-600">{product.prices.installment}</p>
                    <p className="text-sm sm:text-base text-gray-700">ou <span className="font-bold">{product.prices.cash}</span> à vista</p>
                  </div>
                </CardContent>
                <CardFooter className="p-4 sm:p-6 pt-0">
                  <Button 
                    className="w-full bg-green-500 hover:bg-green-600 py-5 sm:py-6 text-sm sm:text-base"
                    onClick={() => handleWhatsAppClick(product.name)}
                  >
                    <MessageCircle className="mr-2 h-4 w-4 sm:h-5 sm:w-5" />
                    Consultar Preço
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>

          {/* Botão Ver Mais Modelos - VERDE */}
          <div className="text-center mt-8 sm:mt-12">
            <Button 
              size="lg"
              className="bg-green-500 hover:bg-green-600 text-white font-bold py-5 sm:py-6 px-6 sm:px-8 text-base sm:text-lg w-full sm:w-auto"
              onClick={() => handleWhatsAppClick()}
            >
              <MessageCircle className="mr-2 h-5 w-5 sm:h-6 sm:w-6" />
              Ver Mais Modelos no WhatsApp
            </Button>
          </div>
        </div>
      </section>

      {/* Dicas de Manutenção - Otimizado para Mobile */}
      <section className="py-12 sm:py-16 md:py-20 bg-gray-50 px-4">
        <div className="container mx-auto">
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-center mb-8 sm:mb-12">
            Dicas de <span className="text-red-600">Manutenção</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <Battery className="w-10 h-10 sm:w-12 sm:h-12 mx-auto text-green-500 mb-4" />
                <CardTitle className="text-base sm:text-lg">Bateria</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xs sm:text-sm text-gray-600">
                  Carregue regularmente, mesmo sem uso. Evite descargas completas para prolongar a vida útil.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <Settings className="w-10 h-10 sm:w-12 sm:h-12 mx-auto text-blue-500 mb-4" />
                <CardTitle className="text-base sm:text-lg">Revisões</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xs sm:text-sm text-gray-600">
                  Faça revisões periódicas em nossa oficina. Prevenção é economia!
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <Droplets className="w-10 h-10 sm:w-12 sm:h-12 mx-auto text-cyan-500 mb-4" />
                <CardTitle className="text-base sm:text-lg">Limpeza</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xs sm:text-sm text-gray-600">
                  Use pano úmido. Evite jatos d'água diretos na parte elétrica.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <HomeIcon className="w-10 h-10 sm:w-12 sm:h-12 mx-auto text-orange-500 mb-4" />
                <CardTitle className="text-base sm:text-lg">Armazenamento</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xs sm:text-sm text-gray-600">
                  Guarde em local coberto e arejado. Proteja da chuva e sol intenso.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* FAQ - Otimizado para Mobile */}
      <section className="py-12 sm:py-16 md:py-20 bg-white px-4">
        <div className="container mx-auto max-w-3xl">
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-center mb-8 sm:mb-12">
            Perguntas <span className="text-red-600">Frequentes</span>
          </h2>
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader 
                  className="cursor-pointer p-4 sm:p-6"
                  onClick={() => setOpenFaq(openFaq === index ? null : index)}
                >
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-base sm:text-lg md:text-xl pr-4">{faq.question}</CardTitle>
                    <ChevronDown 
                      className={`w-5 h-5 sm:w-6 sm:h-6 transition-transform flex-shrink-0 ${
                        openFaq === index ? 'transform rotate-180' : ''
                      }`}
                    />
                  </div>
                </CardHeader>
                {openFaq === index && (
                  <CardContent className="p-4 sm:p-6 pt-0">
                    <p className="text-sm sm:text-base text-gray-600">{faq.answer}</p>
                  </CardContent>
                )}
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contato Final - Otimizado para Mobile */}
      <section className="py-12 sm:py-16 md:py-20 bg-red-600 text-white px-4">
        <div className="container mx-auto text-center">
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-6 sm:mb-8">
            Pronto Para Sua Liberdade Elétrica?
          </h2>
          <p className="text-base sm:text-lg md:text-xl mb-6 sm:mb-8 max-w-2xl mx-auto">
            Visite nossa loja em Formiga-MG ou entre em contato pelo WhatsApp. Estamos prontos para te atender!
          </p>
          <div className="flex flex-col sm:flex-row justify-center items-center gap-4 sm:gap-6 mb-8 sm:mb-10 text-sm sm:text-base">
            <div className="flex items-center gap-2">
              <Phone className="w-5 h-5 sm:w-6 sm:h-6" />
              <span>(37) 99805-0088</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="w-5 h-5 sm:w-6 sm:h-6" />
              <span>Rua General Carneiro, 43 - Centro, Formiga - MG</span>
            </div>
          </div>
          <Button 
            size="lg" 
            className="bg-white text-red-600 hover:bg-gray-100 font-bold py-5 sm:py-6 px-6 sm:px-8 text-base sm:text-lg w-full sm:w-auto"
            onClick={() => handleWhatsAppClick()}
          >
            <MessageCircle className="mr-2 h-5 w-5 sm:h-6 sm:w-6" />
            Falar com Especialista
          </Button>
        </div>
      </section>

      {/* Botões Flutuantes - WhatsApp e Instagram - Posição Elevada */}
      <div className="fixed bottom-20 sm:bottom-24 right-4 sm:right-6 z-50 flex flex-col gap-3 sm:gap-4">
        <button
          onClick={handleInstagramClick}
          className="bg-gradient-to-br from-purple-600 via-pink-500 to-orange-400 text-white p-3 sm:p-4 rounded-full shadow-lg hover:scale-110 transition-transform animate-pulse"
          aria-label="Instagram"
        >
          <Instagram className="w-6 h-6 sm:w-7 sm:h-7" />
        </button>
        
        <button
          onClick={() => handleWhatsAppClick()}
          className="bg-green-500 text-white p-3 sm:p-4 rounded-full shadow-lg hover:scale-110 transition-transform animate-pulse"
          aria-label="WhatsApp"
        >
          <MessageCircle className="w-6 h-6 sm:w-7 sm:h-7" />
        </button>
      </div>

      {/* Modal de Imagem com Zoom */}
      {selectedImage && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-90 z-50 flex items-center justify-center p-4"
          onClick={handleCloseImage}
        >
          <div className="relative max-w-4xl w-full" onClick={(e) => e.stopPropagation()}>
            <button
              onClick={handleCloseImage}
              className="absolute -top-10 right-0 text-white hover:text-gray-300 transition-colors"
            >
              <X className="w-8 h-8" />
            </button>
            
            <div className="overflow-auto max-h-[80vh] bg-black rounded-lg">
              <img 
                src={selectedImage} 
                alt="Produto ampliado"
                style={{ transform: `scale(${imageZoom})` }}
                className="w-full h-auto transition-transform duration-200 origin-center"
              />
            </div>
            
            <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex gap-4 bg-white bg-opacity-90 rounded-full px-4 py-2">
              <button
                onClick={handleZoomOut}
                disabled={imageZoom <= 1}
                className="p-2 hover:bg-gray-200 rounded-full disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <ZoomOut className="w-6 h-6" />
              </button>
              <span className="flex items-center px-2 font-semibold">{Math.round(imageZoom * 100)}%</span>
              <button
                onClick={handleZoomIn}
                disabled={imageZoom >= 3}
                className="p-2 hover:bg-gray-200 rounded-full disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <ZoomIn className="w-6 h-6" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}


